import * as React from 'react';

/**
 * @startingPoint section="Navigation" subtitle="36px nav-rail icon with hover tooltip" viewport="300x120"
 */
export interface SidebarNavItemProps {
  icon: React.ReactNode;
  label: string;
  active?: boolean;
}
export declare function SidebarNavItem(props: SidebarNavItemProps): JSX.Element;
