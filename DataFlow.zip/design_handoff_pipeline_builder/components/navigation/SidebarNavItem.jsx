import React from 'react';

/** 36px nav-rail item with hover tooltip — mirrors the AppShell sidebar icons. */
export function SidebarNavItem({ icon, label, active = false }) {
  const [hover, setHover] = React.useState(false);
  return (
    <div
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{ position: 'relative', display: 'flex' }}
    >
      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'center', width: 36, height: 36,
        borderRadius: 'var(--radius-md)', cursor: 'pointer',
        border: `1px solid ${active ? 'rgba(168,157,248,.2)' : 'transparent'}`,
        background: active ? 'rgba(124,108,242,.15)' : hover ? 'var(--gray-100)' : 'transparent',
        color: active ? 'var(--brand-500)' : hover ? 'var(--gray-700)' : 'var(--gray-400)',
      }}>
        {icon}
      </div>
      {hover && (
        <span style={{
          position: 'absolute', left: 46, top: '50%', transform: 'translateY(-50%)', zIndex: 10,
          whiteSpace: 'nowrap', padding: '4px 8px', borderRadius: 8, fontSize: 11,
          background: 'rgba(17,24,39,.95)', color: '#fff', fontFamily: 'var(--font-sans)',
          boxShadow: '0 8px 20px rgba(0,0,0,.25)',
        }}>{label}</span>
      )}
    </div>
  );
}
