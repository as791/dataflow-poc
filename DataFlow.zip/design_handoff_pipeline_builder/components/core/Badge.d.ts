import * as React from 'react';

export interface BadgeProps {
  tone?: 'neutral' | 'success' | 'warning' | 'danger';
  /** Show a small status dot before the label (used for run/connection status). */
  dot?: boolean;
  children?: React.ReactNode;
}

/**
 * @startingPoint section="Core" subtitle="Status pill: neutral/success/warning/danger" viewport="700x180"
 */
export declare function Badge(props: BadgeProps): JSX.Element;
