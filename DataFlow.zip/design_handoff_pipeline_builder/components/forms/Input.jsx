import React from 'react';

/** Single-line field — mirrors .glass-input. Pass `icon` as a small ReactNode (e.g. an inline svg or lucide element) for a leading glyph. */
export function Input({ value, onChange, placeholder, type = 'text', icon, disabled = false, style }) {
  return (
    <div style={{ position: 'relative', display: 'flex', alignItems: 'center', ...style }}>
      {icon && (
        <span style={{
          position: 'absolute', left: 10, width: 13, height: 13, color: 'var(--text-tertiary)',
          pointerEvents: 'none', display: 'flex',
        }}>{icon}</span>
      )}
      <input
        type={type}
        value={value}
        onChange={onChange}
        placeholder={placeholder}
        disabled={disabled}
        style={{
          width: '100%', background: 'var(--gray-50)', border: '1px solid var(--border-default)',
          borderRadius: 'var(--radius-md)', padding: icon ? '8px 12px 8px 30px' : '8px 12px',
          fontSize: 'var(--text-body)', color: 'var(--text-primary)', outline: 'none', fontFamily: 'var(--font-sans)',
          transition: 'all var(--duration-standard) var(--ease-standard)',
        }}
      />
    </div>
  );
}
