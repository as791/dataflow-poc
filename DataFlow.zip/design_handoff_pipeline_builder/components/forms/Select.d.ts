import * as React from 'react';

/**
 * @startingPoint section="Components" subtitle="Dropdown select — glass-select" viewport="400x90"
 */
export interface SelectProps {
  value?: string;
  onChange?: (e: React.ChangeEvent<HTMLSelectElement>) => void;
  options: Array<string | { value: string; label: string }>;
  disabled?: boolean;
}
export declare function Select(props: SelectProps): JSX.Element;
