import React from 'react';

export function Select({ value, onChange, options, disabled = false }) {
  return (
    <div style={{ position: 'relative' }}>
      <select
        value={value}
        onChange={onChange}
        disabled={disabled}
        style={{
          width: '100%', appearance: 'none', cursor: disabled ? 'not-allowed' : 'pointer',
          background: 'var(--gray-50)', border: '1px solid var(--border-default)',
          borderRadius: 'var(--radius-md)', padding: '8px 30px 8px 12px',
          fontSize: 'var(--text-body)', color: 'var(--text-primary)', outline: 'none', fontFamily: 'var(--font-sans)',
        }}
      >
        {options.map(o => (
          <option key={typeof o === 'string' ? o : o.value} value={typeof o === 'string' ? o : o.value}>
            {typeof o === 'string' ? o : o.label}
          </option>
        ))}
      </select>
      <span style={{
        position: 'absolute', right: 10, top: '50%', transform: 'translateY(-50%)',
        fontSize: 10, color: 'var(--text-tertiary)', pointerEvents: 'none',
      }}>▾</span>
    </div>
  );
}
