import * as React from 'react';

/**
 * @startingPoint section="Pipeline" subtitle="Small metric readout — success rate / run count / last run" viewport="500x100"
 */
export interface StatTileProps {
  value: React.ReactNode;
  label: string;
  highlight?: boolean;
  /** Pass the app's current theme — inline-styled dark mode can't rely on CSS-var switching */
  dark?: boolean;
}
export declare function StatTile(props: StatTileProps): JSX.Element;
