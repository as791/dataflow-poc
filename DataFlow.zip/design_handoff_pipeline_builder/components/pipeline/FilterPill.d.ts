import * as React from 'react';

/**
 * @startingPoint section="Pipeline" subtitle="Toolbar filter chip with count — All/Production/Draft/Failed" viewport="700x100"
 */
export interface FilterPillProps {
  label: string;
  count?: number;
  /** Small status dot color, e.g. '#34d399' */
  dotColor?: string;
  active?: boolean;
  onClick?: () => void;
  /** Pass the app's current theme — inline-styled dark mode can't rely on CSS-var switching */
  dark?: boolean;
}
export declare function FilterPill(props: FilterPillProps): JSX.Element;
