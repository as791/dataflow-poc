import React from 'react';

/** Gradient provider avatar — mirrors ProviderIcon in ConnectorsPage.tsx. Pass any small ReactNode icon. */
export function ConnectorAvatar({ icon, from = '#6b7280', to = '#4b5563', size = 40 }) {
  return (
    <div style={{
      width: size, height: size, borderRadius: 'var(--radius-lg)',
      background: `linear-gradient(135deg, ${from}, ${to})`,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      color: '#fff', boxShadow: '0 4px 14px rgba(0,0,0,.15)', flexShrink: 0,
    }}>
      {icon}
    </div>
  );
}
