import React from 'react';

/** Small stat readout — mirrors the 3-column success-rate/runs/last-run row in the pipeline drawer. Pass `dark` since the app toggles theme via inline styles, not a CSS class. */
export function StatTile({ value, label, highlight = false, dark = false }) {
  return (
    <div style={{
      padding: '12px 0', textAlign: 'center', flex: 1, fontFamily: 'var(--font-sans)',
    }}>
      <div style={{
        fontSize: 17, fontWeight: 'var(--weight-semibold)', letterSpacing: '-0.02em',
        color: highlight ? '#10b981' : dark ? 'rgba(255,255,255,.9)' : 'var(--text-primary)',
      }}>{value}</div>
      <div style={{
        fontSize: 10, textTransform: 'uppercase', letterSpacing: '0.08em', color: dark ? 'rgba(255,255,255,.35)' : 'var(--text-tertiary)', marginTop: 2,
      }}>{label}</div>
    </div>
  );
}
