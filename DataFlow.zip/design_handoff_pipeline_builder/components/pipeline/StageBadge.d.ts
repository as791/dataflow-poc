import * as React from 'react';

/**
 * @startingPoint section="Pipeline" subtitle="Lifecycle stage pill: draft/testing/production/archived" viewport="500x100"
 */
export interface StageBadgeProps {
  stage?: 'draft' | 'testing' | 'production' | 'archived';
  /** 'md' for prominent placements (e.g. a detail-drawer header) */
  size?: 'sm' | 'md';
}
export declare function StageBadge(props: StageBadgeProps): JSX.Element;
