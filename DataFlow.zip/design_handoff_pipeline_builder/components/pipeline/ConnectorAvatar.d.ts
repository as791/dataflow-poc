import * as React from 'react';

/**
 * @startingPoint section="Pipeline" subtitle="Gradient provider avatar — Google/Microsoft/Zendesk connect cards" viewport="500x100"
 */
export interface ConnectorAvatarProps {
  icon?: React.ReactNode;
  from?: string;
  to?: string;
  size?: number;
}
export declare function ConnectorAvatar(props: ConnectorAvatarProps): JSX.Element;
