import React from 'react';

const STATUS_DOT = { failed: '#f87171', success: '#34d399', running: '#fbbf24' };

/** Pipeline-canvas node card — mirrors FlowNode.tsx: left accent bar, icon tile, label, status dot, record count. */
export function FlowNode({ label, sublabel, icon, color = '#6965db', status, recordCount }) {
  return (
    <div style={{
      position: 'relative', minWidth: 190, borderRadius: 'var(--radius-lg)', padding: '12px 14px',
      background: '#fff', border: '1px solid var(--border-default)', boxShadow: 'var(--shadow-node-light)',
      fontFamily: 'var(--font-sans)', overflow: 'hidden',
    }}>
      <div style={{ position: 'absolute', insetBlock: 0, left: 0, width: 3, background: color }} />
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <span style={{
          width: 32, height: 32, borderRadius: 'var(--radius-md)', background: 'var(--gray-50)',
          border: '1px solid var(--gray-100)', color, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
        }}>{icon}</span>
        <div style={{ minWidth: 0, flex: 1 }}>
          <div style={{ fontSize: 13, fontWeight: 'var(--weight-semibold)', color: 'var(--text-primary)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{label}</div>
          {sublabel && <div style={{ fontSize: 10, color: 'var(--text-tertiary)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{sublabel}</div>}
        </div>
        {status && <span style={{ width: 8, height: 8, borderRadius: '50%', background: STATUS_DOT[status] || '#d1d5db', flexShrink: 0 }} />}
      </div>
      {recordCount != null && (
        <div style={{ marginTop: 8, fontSize: 10, color: 'var(--text-tertiary)' }}>{recordCount.toLocaleString()} records</div>
      )}
    </div>
  );
}
