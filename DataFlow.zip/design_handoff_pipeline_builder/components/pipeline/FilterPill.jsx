import React from 'react';

/** Toolbar filter chip with a count — mirrors the pill row atop PipelinesPage/RunsPage. Pass `dark` since the app toggles theme via inline styles, not a CSS class. */
export function FilterPill({ label, count, dotColor, active = false, onClick, dark = false }) {
  return (
    <button
      onClick={onClick}
      style={{
        display: 'inline-flex', alignItems: 'center', gap: 6, padding: '5px 12px',
        borderRadius: 'var(--radius-pill)', fontSize: 11, fontWeight: 'var(--weight-medium)',
        fontFamily: 'var(--font-sans)', cursor: 'pointer',
        border: `1px solid ${active ? (dark ? '#e5e7eb' : '#111827') : dark ? 'rgba(255,255,255,.14)' : 'var(--border-default)'}`,
        background: active ? (dark ? '#e5e7eb' : '#111827') : 'transparent',
        color: active ? (dark ? '#111827' : '#fff') : dark ? 'rgba(255,255,255,.55)' : 'var(--text-secondary)',
      }}
    >
      {dotColor && <span style={{ width: 6, height: 6, borderRadius: '50%', background: dotColor }} />}
      {label}
      {count != null && <span style={{ color: active ? (dark ? 'rgba(17,24,39,.6)' : 'rgba(255,255,255,.6)') : dark ? 'rgba(255,255,255,.35)' : 'var(--text-tertiary)', marginLeft: 2 }}>{count}</span>}
    </button>
  );
}
