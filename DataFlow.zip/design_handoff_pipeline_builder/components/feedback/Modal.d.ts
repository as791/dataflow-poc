import * as React from 'react';

/**
 * @startingPoint section="Feedback" subtitle="Blurred backdrop dialog — glass-modal" viewport="500x260"
 */
export interface ModalProps {
  title: string;
  onClose: () => void;
  children?: React.ReactNode;
  /** Right-aligned action row, e.g. Cancel / Confirm buttons */
  footer?: React.ReactNode;
  width?: number;
}
export declare function Modal(props: ModalProps): JSX.Element;
