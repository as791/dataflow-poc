import React from 'react';

/** Centered dialog with backdrop blur — mirrors .glass-modal-backdrop / .glass-modal. */
export function Modal({ title, onClose, children, footer, width = 420 }) {
  return (
    <div
      onClick={onClose}
      style={{
        position: 'fixed', inset: 0, background: 'rgba(0,0,0,.4)',
        backdropFilter: 'blur(var(--blur-glass-heavy))', display: 'flex',
        alignItems: 'center', justifyContent: 'center', zIndex: 50,
      }}
    >
      <div
        onClick={e => e.stopPropagation()}
        style={{
          background: '#fff', border: '1px solid var(--border-default)', borderRadius: 'var(--radius-xl)',
          padding: 24, width, maxWidth: 'calc(100% - 32px)', boxShadow: 'var(--shadow-modal-light)',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 }}>
          <h2 style={{ fontSize: 17, fontWeight: 'var(--weight-semibold)', margin: 0, color: 'var(--text-primary)', fontFamily: 'var(--font-sans)' }}>{title}</h2>
          <button
            onClick={onClose}
            aria-label="Close"
            style={{
              width: 32, height: 32, borderRadius: 'var(--radius-md)', border: 'none',
              background: 'var(--gray-100)', color: 'var(--text-secondary)', fontSize: 16, cursor: 'pointer',
            }}
          >×</button>
        </div>
        <div style={{ fontFamily: 'var(--font-sans)', fontSize: 'var(--text-body)', color: 'var(--text-primary)' }}>{children}</div>
        {footer && <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8, marginTop: 20 }}>{footer}</div>}
      </div>
    </div>
  );
}
